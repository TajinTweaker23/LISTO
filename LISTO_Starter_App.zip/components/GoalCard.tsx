// Goal card component (placeholder)
export default function GoalCard() { return <div>Goal Card</div>; }